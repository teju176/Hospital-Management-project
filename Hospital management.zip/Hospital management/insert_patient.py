from connect import Connection # connect file connect.py  and class Connection
class Patient:
    def insert_record(self):
        
        con=Connection()
        
        cur=con.cursor()

       
        q="insert into appointments values(%s,%s,%s,%s,%s,%s,%s)"
        
        
        pid=int(input("Enter patient Id : "))
        n=input("Enter patient Name ")  
        c=int(input("Enter patient city : "))
        m=input("Enter patient Mobile No.  :")
        g=int(input("Enter patient gender :"))
        d=input("Enter patients appointment_date  :") # insertion date format is (yyyy/mm/dd)
        dep=input("Enter Appointment department  :") # ex- Surgery, OTD, Blood test according to patiens isuues
        
        val=(pid,n,c,m,g,d,dep)
        
        try:
            cur.execute(q,val)
        except:
            print("Query Error")
        else:
        
            con.commit()
            print("Record Insert Successfully")
        
            cur.close()
            con.close()
