import pymysql # connectivity code with mysql database
class Connection: 
    def conn(self): 
        
        self.servername="localhost"
        self.username="root"
        self.password=""
        self.dbname="patient_info"
        try:
            self.con=pymysql.connect(self.servername,self.username,self.password,self.dbname)
        except:
            print("Connectivity Error")
        else:
            print("Connect successfully")
            return self.con
