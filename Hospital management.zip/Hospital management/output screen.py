Python 3.9.0 (tags/v3.9.0:9cf6752, Oct  5 2020, 15:34:40) [MSC v.1927 64 bit (AMD64)] on win32
Type "help", "copyright", "credits" or "license()" for more information.
>>> 
============ RESTART: P:\Python study\Hospital management\connect.py ===========
>>> 
======== RESTART: P:\Python study\Hospital management\insert_patient.py ========
>>> 
============ RESTART: P:\Python study\Hospital management\patient.py ===========
>>> 
====== RESTART: P:\Python study\Hospital management\Hospital_Management.py =====

 1. Insert patient appointment 
 2. View All appointments 
 3. Search appointments According pid 
 4. Updation of appointment date 
 5. Delete patients appointment 
 6. Exit 
Enter Your choice : 1
Connect successfully
Enter patient Id : 04
Enter patient Name kavita
Enter patient city : ravet
Enter patient Mobile No.  :8456231789
Enter patient gender :Female
Enter patients appointment_date  :2021/02/12
Enter department  :Surgery
Record Insert Successfully

 1. Insert patient appointment 
 2. View All appointments 
 3. Search appointments According pid 
 4. Updation of appointment date 
 5. Delete patients appointment 
 6. Exit 
Enter Your choice : 2
Connect successfully
(('12', 'Shweta', 'Satara', 2147483647, 'female', datetime.date(2021, 4, 6), 'Xray'), ('13', 'Pratik', 'chennai', 2147483647, 'male', '0000-00-00', 'Blood test'), ('14', 'akash', 'pune', 2147483647, 'male', datetime.date(2021, 2, 1), 'surgery'), ('16', 'onkya', 'baramati', 123, 'male', '0000-00-00', 'cardio'), ('23', 'kini', 'gfd', 4561237895, 'ghar', '0000-00-00', 'cardio'), ('4', 'kavita', 'ravet', 8456231789, 'Female', datetime.date(2021, 2, 12), 'Surgery'))

 1. Insert patient appointment 
 2. View All appointments 
 3. Search appointments According pid 
 4. Updation of appointment date 
 5. Delete patients appointment 
 6. Exit 
Enter Your choice : 3
Enter patient id no. to be Searched : 04
Connect successfully
('4', 'kavita', 'ravet', 8456231789, 'Female', datetime.date(2021, 2, 12), 'Surgery')

 1. Insert patient appointment 
 2. View All appointments 
 3. Search appointments According pid 
 4. Updation of appointment date 
 5. Delete patients appointment 
 6. Exit 
Enter Your choice : 4
Connect successfully
Enter patient id:  04
Enter new date : 2021-02-04
0
 Date Sucessfully updated

 1. Insert patient appointment 
 2. View All appointments 
 3. Search appointments According pid 
 4. Updation of appointment date 
 5. Delete patients appointment 
 6. Exit 
Enter Your choice : 4
Connect successfully
Enter patient id:  04
Enter new date : 2021/02/04
0
 Date Sucessfully updated

 1. Insert patient appointment 
 2. View All appointments 
 3. Search appointments According pid 
 4. Updation of appointment date 
 5. Delete patients appointment 
 6. Exit 
Enter Your choice : 5
Connect successfully
Enter patient id no. to be deleted : 04
Appointment deleted successfully

 1. Insert patient appointment 
 2. View All appointments 
 3. Search appointments According pid 
 4. Updation of appointment date 
 5. Delete patients appointment 
 6. Exit 
Enter Your choice : 3
Enter patient id no. to be Searched : 04
Connect successfully
None

 1. Insert patient appointment 
 2. View All appointments 
 3. Search appointments According pid 
 4. Updation of appointment date 
 5. Delete patients appointment 
 6. Exit 
Enter Your choice : 