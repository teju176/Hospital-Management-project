from connect import Connection
import datetime
from datetime import date
class patient:
    def insert_record(self):
        con1=Connection()
        con=con1.conn()
        
        cur=con.cursor()

        
        q="insert into appointments values(%s,%s,%s,%s,%s,%s,%s)"
        
        
        pid=int(input("Enter patient Id : "))
        n=input("Enter patient Name ")  
        c=input("Enter patient city : ")
        m=input("Enter patient Mobile No.  :")
        g=input("Enter patient gender :")
        d=input("Enter patients appointment_date  :")
        dep=input("Enter department  :")
        
        val=(pid,n,c,m,g,d,dep)
        
        try:
            cur.execute(q,val)
        except:
            print("Query Error")
        else:
        
            con.commit()
            print("Record Insert Successfully")
        
            cur.close()
            con.close()

 
    def menu(self):
        print("\n 1. Insert patient appointment \n 2. View All appointments \n 3. Search appointments According pid \n 4. Updation of appointment date \n 5. Delete patients appointment \n 6. Exit ")
        

    def View_appointments(self):
        
        con1=Connection()
        con=con1.conn()
                 
        query="SELECT * FROM appointments"
                    
        cur=con.cursor()
                   
        cur.execute(query)
        result=cur.fetchall()  
        print(result)
        cur.close()
        con.close()
    def Search_appointments(self):
       pid=int(input("Enter patient id no. to be Searched : "))
        
       con1=Connection()
       con=con1.conn()
                 
       cur=con.cursor()
                    
       cur.execute(f"SELECT * FROM appointments where patient_id={pid}")
       
       result=cur.fetchone()  
       print(result)
       cur.close()
       con.close()
    def Update_appointment_date(self):
        con1=Connection()
        con=con1.conn()
        pid=input("Enter patient id:  ")
        
        
        
        q=("UPDATE appointments SET appointment_date=%s where patient_id=%s")
        try:
            cur=con.cursor()
            cur.execute(f"SELECT * FROM appointments WHERE patient_id={pid}")
            result=cur.fetchone()
            if len(result)>1:
                Update_appointment_date=input("Enter new date : ")
                cur.execute(q,(Update_appointment_date,pid))
                print(cur.rowcount)
                con.commit() 
                print(" Date Sucessfully updated")
        except:
            print("Date are not updated")
            cur.close()

    def delete(self):
        con1=Connection()
        con=con1.conn()
        pid=int(input("Enter patient id no. to be deleted : "))
        cur=con.cursor()
        try:
            cur.execute(f"SELECT * FROM appointments WHERE patient_id={pid}")
            result=cur.fetchone()
            
            if len(result)>1:
                cur.execute(f"delete  FROM appointments WHERE patient_id={pid}")
                con.commit()
                print("Appointment deleted successfully")
                cur.close()
                con.close()
        except:
            print("Appointment not found")
            cur.close()
            con.close()
       
