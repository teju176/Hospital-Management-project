#Main program
from patient import patient
d1=patient()
while(True):
    d1.menu()
    ch=int(input("Enter Your choice : "))
    if(ch==1):
        d1.insert_record()
    elif(ch==2):
        d1.View_appointments()
    elif(ch==3):
        d1.Search_appointments()
    elif(ch==4):
        d1.Update_appointment_date()   
    elif(ch==5):
        d1.delete()
    elif(ch==6):
        break
    
